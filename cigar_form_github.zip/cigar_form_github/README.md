# Cigar Form (Fiche de Dégustation de Cigare)

Ce mini-projet contient un formulaire HTML permettant de générer un **PDF téléchargeable** depuis un navigateur (PC ou iOS).

## 🚀 Déploiement sur GitHub Pages

1. Créez un dépôt sur GitHub (ex: `cigar-form`).
2. Uploadez `index.html` et ce README.md.
3. Allez dans **Settings → Pages → Branch `main` /root** puis sauvegardez.
4. Votre site sera disponible à :

```
https://VOTRE_PSEUDO.github.io/cigar-form/
```

Remplissez le formulaire, cliquez sur **Générer PDF**, et le fichier sera téléchargeable.
